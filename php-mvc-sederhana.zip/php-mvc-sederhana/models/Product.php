<?php
class Product {
    public function __construct(private PDO $pdo) {}
    public function all(): array {
        $stmt = $this->pdo->query("SELECT id, name, price FROM products ORDER BY id DESC");
        return $stmt->fetchAll();
    }
    public function find(int $id): ?array {
        $stmt = $this->pdo->prepare("SELECT id, name, price FROM products WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $product = $stmt->fetch();
        return $product ?: null;
    }
    public function create(string $name, int $price): bool {
        $stmt = $this->pdo->prepare("INSERT INTO products (name, price) VALUES (:name, :price)");
        return $stmt->execute([':name' => $name, ':price' => $price]);
    }
    public function update(int $id, string $name, int $price): bool {
        $stmt = $this->pdo->prepare("UPDATE products SET name = :name, price = :price WHERE id = :id");
        return $stmt->execute([':name' => $name, ':price' => $price, ':id' => $id]);
    }
    public function delete(int $id): bool {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
