<?php
class ProductController {
    public function __construct(private Product $product) {}
    public function index(): void {
        $products = $this->product->all();
        require __DIR__ . '/../views/products/index.php';
    }
    public function store(): void {
        $name = trim($_POST['name'] ?? '');
        $price = (int)($_POST['price'] ?? 0);
        if ($name === '' || $price <= 0) {
            $_SESSION['message'] = 'Nama produk dan harga harus diisi dengan benar.';
            header('Location: index.php?action=index'); exit;
        }
        $this->product->create($name, $price);
        $_SESSION['message'] = 'Produk berhasil ditambahkan.';
        header('Location: index.php?action=index'); exit;
    }
    public function edit(): void {
        $id = (int)($_GET['id'] ?? 0);
        $product = $this->product->find($id);
        if (!$product) {
            $_SESSION['message'] = 'Produk tidak ditemukan.';
            header('Location: index.php?action=index'); exit;
        }
        require __DIR__ . '/../views/products/edit.php';
    }
    public function update(): void {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $price = (int)($_POST['price'] ?? 0);
        if ($id <= 0 || $name === '' || $price <= 0) {
            $_SESSION['message'] = 'Data produk tidak valid.';
            header('Location: index.php?action=index'); exit;
        }
        $this->product->update($id, $name, $price);
        $_SESSION['message'] = 'Produk berhasil diperbarui.';
        header('Location: index.php?action=index'); exit;
    }
    public function delete(): void {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) { $this->product->delete($id); }
        $_SESSION['message'] = 'Produk berhasil dihapus.';
        header('Location: index.php?action=index'); exit;
    }
}
