<?php $pageTitle = $pageTitle ?? 'PHP MVC Sederhana'; ?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title><link rel="stylesheet" href="assets/style.css">
</head><body><div class="container"><header class="header"><div><span class="eyebrow">PHP NATIVE</span><h1>Produk Sederhana</h1><p>Contoh implementasi pola MVC.</p></div><a class="button" href="index.php?action=index">Daftar Produk</a></header><main>
<?php if (!empty($_SESSION['message'])): ?><div class="alert"><?= htmlspecialchars($_SESSION['message']) ?></div><?php unset($_SESSION['message']); endif; ?>
