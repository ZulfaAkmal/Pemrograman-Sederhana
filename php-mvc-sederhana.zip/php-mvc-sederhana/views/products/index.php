<?php $pageTitle = 'Daftar Produk'; require __DIR__ . '/../layout/header.php'; ?>
<section class="grid"><div class="card"><h2>Tambah Produk</h2><p class="muted">Masukkan nama dan harga produk.</p>
<form method="post" action="index.php?action=store"><label for="name">Nama Produk</label><input id="name" name="name" type="text" maxlength="100" required>
<label for="price">Harga</label><input id="price" name="price" type="number" min="1" required><button class="button full" type="submit">Simpan Produk</button></form></div>
<div class="card"><div class="card-head"><div><h2>Daftar Produk</h2><p class="muted">Data diambil melalui Model.</p></div><span class="count"><?= count($products) ?> produk</span></div>
<?php if (!$products): ?><div class="empty">Belum ada produk.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>Nama</th><th>Harga</th><th>Aksi</th></tr></thead><tbody>
<?php foreach ($products as $product): ?><tr><td><?= htmlspecialchars($product['name']) ?></td><td>Rp<?= number_format((int)$product['price'], 0, ',', '.') ?></td><td class="actions">
<a class="button small secondary" href="index.php?action=edit&id=<?= (int)$product['id'] ?>">Edit</a>
<a class="button small danger" href="index.php?action=delete&id=<?= (int)$product['id'] ?>" onclick="return confirm('Hapus produk ini?')">Hapus</a>
</td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div></section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
