<?php $pageTitle = 'Edit Produk'; require __DIR__ . '/../layout/header.php'; ?>
<section class="card narrow"><h2>Edit Produk</h2><p class="muted">Perbarui data produk yang dipilih.</p>
<form method="post" action="index.php?action=update"><input type="hidden" name="id" value="<?= (int)$product['id'] ?>">
<label for="name">Nama Produk</label><input id="name" name="name" type="text" value="<?= htmlspecialchars($product['name']) ?>" maxlength="100" required>
<label for="price">Harga</label><input id="price" name="price" type="number" value="<?= (int)$product['price'] ?>" min="1" required>
<div class="actions"><a class="button secondary" href="index.php?action=index">Batal</a><button class="button" type="submit">Simpan Perubahan</button></div></form></section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
