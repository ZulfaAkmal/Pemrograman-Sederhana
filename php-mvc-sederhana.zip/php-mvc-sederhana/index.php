<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/models/Product.php';
require_once __DIR__ . '/controllers/ProductController.php';
$productModel = new Product($pdo);
$productController = new ProductController($productModel);
$action = $_GET['action'] ?? 'index';
switch ($action) {
    case 'store': if ($_SERVER['REQUEST_METHOD'] === 'POST') $productController->store(); break;
    case 'edit': $productController->edit(); break;
    case 'update': if ($_SERVER['REQUEST_METHOD'] === 'POST') $productController->update(); break;
    case 'delete': $productController->delete(); break;
    case 'index': default: $productController->index(); break;
}
